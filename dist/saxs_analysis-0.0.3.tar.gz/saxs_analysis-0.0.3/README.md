# SAXS_analysis

This project has received funding from the European Research Council (ERC) under the European Union's Horizon 2020 research and innovation programme (grant agreement No 101001567).

## Packges required for the SAXS_analysis

PyFAI version 0.21.3 \
fabio 2022.12.1 \
scipy version 1.9.3 \
matplotlib version 3.6.2 \
ipympl version 0.9.2 \
Python version 3.8.8 
